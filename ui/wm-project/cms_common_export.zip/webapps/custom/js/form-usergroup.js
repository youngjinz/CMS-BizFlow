'use strict';

function UserGroupManager(name_) {
    var _name = name_ || "UserGroupManager";
    var _userGroups;
    var _userGroupMapping = {};
    var _x2js = null;
    var _userGroupMembers = [];

    function initUserGroup(userGroupString) {
        if (userGroupString) {
            _userGroups = _x2js.xml_str2json(userGroupString);
        } else {
            _userGroups = {UserGroups: {}};
        }
    }

    function initUserGroupMapping(userGroupMappingString) {
        if (userGroupMappingString) {
            var userGroupMapping = _x2js.xml_str2json(userGroupMappingString);
            if (userGroupMapping && userGroupMapping.userGroupMapping) {
                _userGroupMapping = FormUtility.arrayToObjects(userGroupMapping.userGroupMapping.record, "KEY");
            }
        }
    }

    this.getCurrentUserGroupName = function (userGroupName) {
        var name = userGroupName;
        var ug = _userGroupMapping[userGroupName];
        if (ug) {
            name = ug.NAME;
        }

        return name || userGroupName;
    };

    this.isUserMemberOf = function (userGroupName) {
        var isMember = _userGroupMembers[userGroupName];
        if (undefined === isMember || null == isMember) {
            var rc = false;
            var currentUserGroupName = this.getCurrentUserGroupName(userGroupName);
            if (_userGroups && _userGroups.UserGroups && _userGroups.UserGroups.UserGroup) {
                var foundGroups = _userGroups.UserGroups.UserGroup.filter(function (node, index) {
                    return node.Name == currentUserGroupName
                });
                rc = foundGroups.length > 0;
            }
            _userGroupMembers[userGroupName] = rc;
            return rc;
        } else {
            return isMember;
        }
    };

    this.init = function (userGroupString, userGroupMappingString) {
        _x2js = new X2JS();
        initUserGroup(userGroupString);
        initUserGroupMapping(userGroupMappingString);
        _x2js = null;
    };
}

(function (window) {
    var _initializer = window.MyUserGroupManager || (window.MyUserGroupManager = new UserGroupManager('MyUserGroupManager'));
})(window);