'use strict';

(function (window) {
    var BizFlowAngularApp = function (angular) {
        angular.module('bizflow.app', [
            'ngSanitize',
            'blockUI',
            'ngAnimate',
            'ngCookies',
            'inform',
            'inform-exception',
            'ui.bootstrap',
            'ui.select',
            'ui.grid',
            'ui.grid.selection',
            'ui.grid.pagination',
            'ui.grid.autoResize',
            'ui.grid.resizeColumns',
            'ngMessages',
            'bizflow.angular.context',
            'bizflow.angular.wih',
            'bizflow.angular.component',
            'bizflow.app.common'])
            .factory('timeoutHttpIntercept', function (inform) {
                return {
                    'request': function (config) {
                        config.timeout = 600000; // increase timeout for Excel download operation
                        return config;
                    },
                    'responseError': function (responseError) {
                        if (responseError.status === -1 || responseError.status === 499 || responseError.status === 598 || responseError.status === 599) {
                            inform.add('Error: Time out', {type: 'danger'})
                        }
                        return responseError;
                    }
                };
            })
            .config(['$httpProvider', 'blockUIConfig', 'bizflowContextProvider', 'informProvider', '$compileProvider', '$logProvider',
                function ($httpProvider, blockUIConfig, bizflowContextProvider, informProvider, $compileProvider, $logProvider) {
                    // Turn on or off debugging message
                    $logProvider.debugEnabled(true);
                    bizflowContextProvider.custom.debugEnabled = $logProvider.debugEnabled();
                    bizflowContextProvider.custom.formStyle = 'tab';

                    $httpProvider.interceptors.push('timeoutHttpIntercept');

                    blockUIConfig.autoBlock = true;
                    blockUIConfig.delay = 0;
                    blockUIConfig.message = 'Please Wait...';
                    // Disable auto body block(This is important! if it's value is true then browser will be flickering on ie 9 and ie 10)
                    blockUIConfig.autoInjectBodyBlock = false;
                    // ... don't block it.
                    blockUIConfig.requestFilter = function (config) {
                    };

                    // Need to change bizflowsrs context patch if it is not default value bizflowsrs
                    bizflowContextProvider.setServiceContextPath('/bizflowsrs/services');
                    bizflowContextProvider.setDataServiceContextPath('/bizflowsrs/services');
                    bizflowContextProvider.setAppContextPath('/bizflowwebmaker/cms_common');

                    informProvider.defaults({ttl: 0, type: 'danger'});

                    // need to set as false for PRODUCTION SERVER to speed up
                    // https://docs.angularjs.org/guide/production
                    $compileProvider.debugInfoEnabled(false);
                }
            ])
            .controller('CtrlAppMain', function ($scope, $location, bizflowContext, $document, $window, $rootScope, $log, bizflowWih, $timeout) {
                var vm = this;
                vm.bizflowContext = bizflowContext;

                $scope.$ctrl = vm;
                $scope.isContextLoaded = true;

                // trigger destroy events for all children when window is switched or closed
                $window.onbeforeunload = function () {
                    $rootScope.$destroy();
                };
                $scope.$on('$destroy', function () {
                });

                vm.isUseSection508 = function () {
                    if (typeof FormSection508 !== "undefined") return FormSection508.isUseSection508();
                    else return false;
                };

                // Prevent backspace from navigating back in AngularJS in IE
                $document.on('keydown', function (event) {
                    if (event.keyCode === 8) {
                        var doPrevent = true;
                        var types = ['text', 'password', 'file', 'search', 'email', 'number', 'date', 'color', 'datetime', 'datetime-local', 'month', 'range', 'search', 'tel', 'time', 'url', 'week'];
                        var d = $(event.srcElement || event.target);
                        var disabled = d.prop('readonly') || d.prop('disabled');
                        if (!disabled) {
                            if (d[0].isContentEditable) {
                                doPrevent = false;
                            } else if (d.is('input')) {
                                var type = d.attr('type');
                                if (type) {
                                    type = type.toLowerCase();
                                }
                                if (types.indexOf(type) > -1) {
                                    doPrevent = false;
                                } else if (d[0].outerHTML.indexOf('textbox') > -1) {
                                    doPrevent = false;
                                } else if (d[0].outerHTML.indexOf('text-box') > -1) {
                                    doPrevent = false;
                                }
                            } else if (d.is('textarea')) {
                                doPrevent = false;
                            }
                        }
                        if (doPrevent) {
                            event.preventDefault();
                        }
                    }
                });

                vm.sortDocumentTypes = function (documentTypes) {
                    var lastEntry = [];
                    if (typeof FormAttachmentHandler !== "undefined") {
                        if (typeof FormAttachmentHandler.isLastEntryDocumentType === 'function') {
                            for (var d = documentTypes.length - 1; d >= 0; d--) {
                                var docType = documentTypes[d];
                                if (FormAttachmentHandler.isLastEntryDocumentType(docType)) {
                                    lastEntry.push(docType);
                                    documentTypes.splice(d, 1);
                                }
                            }
                        }
                    }

                    documentTypes.sort(function (item1, item2) {
                        if (item1.NAME === item2.NAME) {
                            return 0;
                        } else {
                            return (item1.NAME > item2.NAME ? 1 : -1);
                        }
                    });

                    if (lastEntry.length > 0) {
                        lastEntry.forEach(function (item) {
                            documentTypes.push(item);
                        });
                    }

                    documentTypes.forEach(function (item) {
                        item.Label = item.LABEL;
                        item.Name = item.NAME;
                    });
                    documentTypes.dataMap = angularExt.objectToMap(documentTypes, 'Label');
                    return documentTypes;
                };

                vm.getDocumentTypeList = function (async) {
                    async = typeof async !== 'undefined' ? async : false;
                    var documentTypes = [{
                        ACTIVE: '1',
                        DISPORDER: '1',
                        ID: '99',
                        LABEL: 'Others',
                        LTYPE: 'DocumentType',
                        NAME: 'Others',
                        PARENTID: '0'
                    }];
                    try {
                        if (FormState) {
                            if (bizflowWih.basicWih) {
                                var workitemContext = bizflowWih.getWorkitemContext();
                                var procName = workitemContext.Process.Name;
                                var actName = workitemContext.Activity.Name;
                                var userName = workitemContext.User.Name;

                                vm.markers = {
                                    "ruleName": DocumentRuleManager.getRuleName(),
                                    "tenantID": DocumentRuleManager.getTenantId(),
                                    "procName": procName,
                                    "actName": actName,
                                    "userName": userName,
                                    "formName": DocumentRuleManager.getFormName(),
                                    "fields": DocumentRuleManager.getRuleFields()
                                };

                                // check if the same search marker ever used in the current page
                                var markerStr = JSON.stringify(vm.markers);
                                var chasedDocumentType = null;
                                if (typeof vm.markersMap !== 'undefined') {
                                    if (typeof vm.markersMap[markerStr] !== 'undefined') {
                                        var cachedDocumentTypesStr = vm.markersMap[markerStr];
                                        if (typeof cachedDocumentTypesStr !== 'undefined') {
                                            chasedDocumentType = JSON.parse(cachedDocumentTypesStr);
                                            documentTypes = vm.sortDocumentTypes(chasedDocumentType);
                                            vm.documentTypes = documentTypes;
                                        }
                                    }
                                }

                                if (chasedDocumentType == null && vm.markers.ruleName) {
                                    $.ajax({
                                        type: "POST",
                                        url: DocumentRuleManager.getRuleUrl(),
                                        // The key needs to match your method's input parameter (case-sensitive).
                                        data: markerStr,
                                        contentType: "application/json; charset=utf-8",
                                        dataType: "json",
                                        success: function (data) {
                                            documentTypes = vm.sortDocumentTypes(data);
                                            if (typeof vm.markersMap !== 'undefined') { // save the result to cache not to call the RESTFul API again until new search conditions used.
                                                vm.markersMap[JSON.stringify(vm.markers)] = JSON.stringify(data);
                                            }

                                            if (async) {
                                                $scope.$apply(function () {
                                                    vm.documentTypes = documentTypes;
                                                    vm.missingDocumentList = vm.getMissingDocumentList();
                                                    vm.setMandatoryDocumentsValidation();
                                                });
                                            }
                                        },
                                        failure: function (errMsg) {
                                            documentTypes = [{
                                                ACTIVE: '1',
                                                DISPORDER: '1',
                                                ID: '99',
                                                LABEL: 'Others',
                                                LTYPE: 'DocumentType',
                                                NAME: 'Others',
                                                PARENTID: '0'
                                            }];
                                            vm.documentTypes = documentTypes;
                                        },
                                        async: async
                                    });
                                }
                            }
                        }
                    } catch (e) {
                        // Intentionally Empty
                        // The exception will be generated only when the form is initially loaded. No need to have the document type list is set at that moment.
                    }

                    return documentTypes;
                };
                vm.getMissingDocumentList = function () {
                    // For the activities requiring no hard stopping
                    if (DocumentRuleManager.isNoCheckingMissingDocument()) {
                        return [];  // No mandatory document list
                    }

                    var attachments = bizflowWih.getAttachments();
                    var mandatoryDocumentListOrg = [];
                    try {
                        if (FormState) {
                            if (typeof vm.documentTypes !== 'undefined') {
                                for (var i = 0; i < vm.documentTypes.length; i++) {
                                    var doc = vm.documentTypes[i];
                                    if (true === doc.REQUIRED) {
                                        mandatoryDocumentListOrg.push(doc);
                                    }
                                }
                            }
                        }
                    } catch (e) {
                        // Intentionally Empty
                        // The exception will be generated only when the form is initally loaded. No need to have the mandatory document list is set at that moment.
                    }

                    var mandatoryDocumentList = mandatoryDocumentListOrg.slice();
                    var attachmentsCopy = attachments.slice();

                    if (attachmentsCopy != null && attachmentsCopy.length > 0) {
                        if (mandatoryDocumentList != null && mandatoryDocumentList.length > 0) {
                            for (var index = mandatoryDocumentList.length - 1; index >= 0; index--) {
                                for (var attachmentIndex = attachmentsCopy.length - 1; attachmentIndex >= 0; attachmentIndex--) {
                                    if (attachmentsCopy[attachmentIndex].CATEGORY === mandatoryDocumentList[index].LABEL) {
                                        mandatoryDocumentList.splice(index, 1);
                                        attachmentsCopy.splice(attachmentIndex, 1);
                                        break;
                                    }
                                }
                            }
                        } else {
                            return []; // No mandatory document list is specified.
                        }
                    }

                    mandatoryDocumentList.sort(function (item1, item2) {
                        if (item1.LABEL === item2.LABEL) {
                            return 0;
                        } else {
                            return (item1.LABEL > item2.LABEL ? 1 : -1);
                        }
                    });
                    return mandatoryDocumentList;
                };

                vm.init = function () {
                    // Prevent backspace from navigating back in AngularJS in IE
                    $document.on('keydown', function (event) {
                        if (event.keyCode === 8) {
                            var doPrevent = true;
                            var types = ['text', 'password', 'file', 'search', 'email', 'number', 'date', 'color', 'datetime', 'datetime-local', 'month', 'range', 'search', 'tel', 'time', 'url', 'week'];
                            var d = $(event.srcElement || event.target);
                            var disabled = d.prop('readonly') || d.prop('disabled');
                            if (!disabled) {
                                if (d[0].isContentEditable) {
                                    doPrevent = false;
                                } else if (d.is('input')) {
                                    var type = d.attr('type');
                                    if (type) {
                                        type = type.toLowerCase();
                                    }
                                    if (types.indexOf(type) > -1) {
                                        doPrevent = false;
                                    } else if (d[0].outerHTML.indexOf('textbox') > -1) {
                                        doPrevent = false;
                                    } else if (d[0].outerHTML.indexOf('text-box') > -1) {
                                        doPrevent = false;
                                    }
                                } else if (d.is('textarea')) {
                                    doPrevent = false;
                                }
                            }
                            if (doPrevent) {
                                event.preventDefault();
                            }
                        }
                    });

                    if (angular.isUndefined(bizflowContext.custom)) bizflowContext.custom = {};

                    var absUrl = $location.absUrl();
                    bizflowContext.custom.bfIntegrationMode = 'workitem'; // login, bizcove, workitem
                    if (bizflowWih.basicWih) {
                        var workitemContext = bizflowWih.getWorkitemContext();
                        bizflowContext.custom.SESSIONINFO = workitemContext.SessionInfoXML;
                        bizflowContext.custom.MEMBERID = workitemContext.User.MemberID;
                        bizflowContext.custom.MEMBERNAME = workitemContext.User.Name;

                        bizflowContext.custom.PROCESSID = workitemContext.Process.ID;
                        bizflowContext.custom.ACTIVITYSEQ = workitemContext.Activity.Sequence;
                        bizflowContext.custom.ACTIVITYNAME = workitemContext.Activity.Name;
                        bizflowContext.custom.WITEMSEQ = workitemContext.Workitem.Sequence;
                        bizflowContext.custom.bfIntegrationMode = 'workitem'; // login, bizcove, workitem
                    }
                };

                vm.markersMap = {};
                vm.markers = {};

                vm.init();

                vm.documentTypes = null;
                vm.missingDocumentList = null;
                vm.getDocumentTypeList(true);

                vm.isBulkProcess = false;
                vm.showHideOriginals = false;
                vm.processID = bizflowContext.custom.PROCESSID;
                vm.isReadOnly = FormUtility.isReadOnly();
                vm.initialRefreshForEligibility = false;

                vm.setMandatoryDocumentsValidation = function () {
                    if (vm.missingDocumentList.length > 0) {
                        $('#h_mandatoryDocumentsValid').val('false');
                    } else {
                        $('#h_mandatoryDocumentsValid').val('true');
                    }
                };

                vm.onChange = function () {
                    if (bizflowWih_attachmentCallback != null) {
                        bizflowWih_attachmentCallback = null;
                    }

                    // Making Document Tab readonly when tab9 is in readonly tab list
                    if (!vm.isReadOnly) {
                        var readOnlyTab = ActivityManager.getReadOnlyTabIdList();
                        if (typeof readOnlyTab !== 'undefined') {
                            var docTabId = DocumentRuleManager.getDocumentTabId();
                            if (readOnlyTab.indexOf(docTabId) >= 0) {
                                vm.isReadOnly = true;
                            }
                        }
                    }

                    vm.documentTypes = vm.getDocumentTypeList();
                    vm.missingDocumentList = vm.getMissingDocumentList();

                    vm.setMandatoryDocumentsValidation();

                    try {
                        $timeout(function () {
                            $scope.$digest();
                        });
                    } catch (e) {
                    }
                };

                $(document).on(FORM_EVENT.TAB_CHANGE, function () {
                    vm.onChange();
                });
                $(document).on(FORM_EVENT.DOCUMENT_CHANGE, function () {
                    vm.onChange();
                })
            });
    };

    var _initializer = window.BizFlowAngularApp || (window.BizFlowAngularApp = BizFlowAngularApp(window.angular));
})(window);

function initAttachmentTab() {
    var attachmentSectionID = document.getElementById('attachmentSectionID');
    if (attachmentSectionID) {
        angular.bootstrap(attachmentSectionID, ['bizflow.app']);
    }
}

function refreshAttachment() {
    var attachmentController = null;

    try {
        attachmentController = angular.element(document.getElementById('hhsattachment')).controller('attachments');
        if (attachmentController != null) {
            attachmentController.reloadAttachments2();
        } else {
            console.log('Failed to retrieve attachments controller.')
        }
    } catch (e) {
        console.log('Exception happened while retrieving attachments controller.');
    }
}

/* Pop up Attachment Dialog box with given document type */
function addCMSDocument(documentTypeString) {
    var attachmentController = null;
    if (documentTypeString == null || documentTypeString.length === 0) {
        documentTypeString = 'Supporting Documents';
    }

    try {
        attachmentController = angular.element(document.getElementById('cmsattachment')).controller('attachments');
    } catch (e) {
        console.log('Failed to retrieve attachments controller.');
    }

    if (attachmentController != null) {
        if (attachmentController.documentTypes != null && attachmentController.documentTypes.length > 0) {
            var foundDocumentType = false;
            for (var index = 0; index < attachmentController.documentTypes.length; index++) {
                if (documentTypeString === attachmentController.documentTypes[index].Name) {
                    foundDocumentType = true;
                    break;
                }
            }

            if (foundDocumentType === false) {
                documentTypeString = 'Supporting Documents';
            }
            attachmentController.addAttachment(documentTypeString);
        }
    }
}

/* Pop up Attachment Dialog box to add Existing PD Document */
function addCMSExistingPDDocument() {
    addCMSDocument('Existing Position Description (PD)');
}

(function (window) {
    var DocumentRuleManager = function () {
        var _ruleUrl = '/bizflowrule/rest/rule/document/getDocumentList.json';
        var _tenantId = 'CMS';
        var _ruleName = null;
        var _formName = null;
        var _noCheckingMissingDocument = false;
        var _docTabId = 'tab9';
        var _fnRuleFields = null;

        function setRuleUrl(ruleUrl) {
            _ruleUrl = ruleUrl;
        }

        function getRuleUrl() {
            return _ruleUrl;
        }

        function setRuleName(ruleName) {
            _ruleName = ruleName;
        }

        function getRuleName() {
            return _ruleName;
        }

        function setTenantId(tenantId) {
            _tenantId = tenantId;
        }

        function getTenantId() {
            return _tenantId;
        }

        function setFormName(formName) {
            _formName = formName;
        }

        function getFormName() {
            return _formName;
        }

        function getRuleFields() {
            var ruleFields = [];
            if (_fnRuleFields) {
                ruleFields = _fnRuleFields();
            }

            return ruleFields;
        }

        function setNoCheckingMissingDocument(hardStopRequired) {
            _noCheckingMissingDocument = hardStopRequired;
        }

        function isNoCheckingMissingDocument() {
            return _noCheckingMissingDocument;
        }

        function setDocumentTabId(docTabId) {
            _docTabId = docTabId;
        }

        function getDocumentTabId() {
            return _docTabId;
        }

        /**
         * Initialize
         * @param ruleName the file name of a rule without extension. for example, cms-incentives-document-rules
         * @param formName a form name
         * @param fnRuleFields_ (Optional) a function to get rule field array.
         * @param tenantId_ a tenant ID. CMS in default
         */
        function init(ruleName, formName, fnRuleFields_, tenantId_) {
            _ruleName = ruleName;
            _formName = formName;
            _fnRuleFields = fnRuleFields_;
            _tenantId = tenantId_ || _tenantId;
        }

        return {
            setRuleUrl: setRuleUrl,
            getRuleUrl: getRuleUrl,
            setRuleName: setRuleName,
            getRuleName: getRuleName,
            setTenantId: setTenantId,
            getTenantId: getTenantId,
            setFormName: setFormName,
            getFormName: getFormName,
            getRuleFields: getRuleFields,
            setNoCheckingMissingDocument: setNoCheckingMissingDocument,
            isNoCheckingMissingDocument: isNoCheckingMissingDocument,
            setDocumentTabId: setDocumentTabId,
            getDocumentTabId: getDocumentTabId,
            init: init
        }
    };

    var _initializer = window.DocumentRuleManager || (window.DocumentRuleManager = DocumentRuleManager());
})(window);
