'use strict';

(function (window) {
    var FormLog = function (logLevel) {
        var LOG_LEVEL = {
            DEBUG: 'DEBUG',
            INFO: 'INFO',
            WARNING: 'WARNING',
            ERROR: 'ERROR'
        };
        var _logLevel = logLevel || LOG_LEVEL.DEBUG;

        function setLogLevel(logLevel) {
            if (logLevel === LOG_LEVEL.ERROR || logLevel === LOG_LEVEL.INFO || logLevel === LOG_LEVEL.DEBUG) {
                _logLevel = logLevel;
            } else {
                _logLevel = LOG_LEVEL.ERROR;
            }
        }

        function getLogLevel() {
            return _logLevel;
        }

        function isDebugLevel() {
            return _logLevel == LOG_LEVEL.DEBUG;
        }

        function isValidObject(o) {
            return o != undefined && o != null;
        }

        function _log(log, message, a_, b_, c_, d_) {
            if (isValidObject(a_) && isValidObject(b_) && isValidObject(c_) && isValidObject(d_)) {
                log(message, a_, b_, c_, d_);
            } else if (isValidObject(a_) && isValidObject(b_) && isValidObject(c_)) {
                log(message, a_, b_, c_);
            } else if (isValidObject(a_) && isValidObject(b_)) {
                log(message, a_, b_);
            } else if (isValidObject(a_)) {
                log(message, a_);
            } else {
                log(message);
            }
        }

        function debugLog(message, a_, b_, c_, d_) {
            if (_logLevel === LOG_LEVEL.DEBUG) {
                _log(console.debug || console.log, message, a_, b_, c_, d_);
            }
        }

        function infoLog(message, a_, b_, c_, d_) {
            if (_logLevel === LOG_LEVEL.DEBUG || _logLevel === LOG_LEVEL.INFO) {
                _log(console.info || console.log, message, a_, b_, c_, d_);
            }
        }

        function warningLog(message, a_, b_, c_, d_) {
            if (_logLevel === LOG_LEVEL.DEBUG || _logLevel === LOG_LEVEL.INFO || _logLevel === LOG_LEVEL.WARNING) {
                _log(console.warn || console.log, message, a_, b_, c_, d_);
            }
        }

        function errorLog(message, a_, b_, c_, d_) {
            if (_logLevel === LOG_LEVEL.DEBUG || _logLevel === LOG_LEVEL.INFO || _logLevel === LOG_LEVEL.WARNING || _logLevel === LOG_LEVEL.ERROR) {
                _log(console.error || console.log, message, a_, b_, c_, d_);
            }
        }

        function log(logLevel, message, a_, b_, c_, d_) {
            try {
                if (logLevel === LOG_LEVEL.DEBUG) {
                    debugLog(message, a_, b_, c_, d_);
                } else if (logLevel === LOG_LEVEL.INFO) {
                    infoLog(message, a_, b_, c_, d_);
                } else if (logLevel === LOG_LEVEL.WARNING) {
                    warningLog(message, a_, b_, c_, d_);
                } else {
                    errorLog(message, a_, b_, c_, d_);
                }
            } catch (e) {
                console.log(e);
            }
        }

        return {
            LOG_LEVEL: LOG_LEVEL,
            setLogLevel: setLogLevel,
            getLogLevel: getLogLevel,
            isDebugLevel: isDebugLevel,
            log: log
        }
    };

    var _initializer = window.FormLog || (window.FormLog = FormLog());
})(window);
