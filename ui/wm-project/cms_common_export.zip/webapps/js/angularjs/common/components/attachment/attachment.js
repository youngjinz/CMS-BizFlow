/**
 * AngularJS component showing BizFlow Attachments.<br>
 * This component can be initiated by adding attachments element into HTML.
 * @component attachments
 * @memberOf module:"bizflow.angular.component"
 *
 * @param {int} BizFlow Process ID
 * @param {array} documentTypes document type array
 * @param {boolean} showHideOriginals The flag showing original attachment information or not.
 * @param {boolean} isBulkProcess The flag showing BizFlow Process ID or not.
 * @param {boolean} readOnly The flag hiding buttons (Add Attachment) or not.
 *
 * @example
 *<attachments
 *      process-id="$ctrl.processId"
 *      document-types="$ctrl.documentTypes"
 *      show-hide-originals="$ctrl.showHideOriginals"
 *      is-bulk-process="false"
 *      read-only="false">
 *</attachments>
 */

(function () {
    'use strict';

    angular.module('bizflow.angular.component')
        .filter('printCreatorName', function () {
            return function (input) {
                if (input && input.CREATORNAME) {
                    if (input.TYPE === 'C' ||
                        angular.lowercase(input.CREATORNAME).indexOf('agent') > -1 ||
                        input.CREATORNAME === 'ERA User') {
                        return 'System';
                    } else {
                        return input.CREATORNAME;
                    }
                } else {
                    return '';
                }
            };
        });

    angular.module('bizflow.angular.component')
        .component('attachments', {
            templateUrl: function ($element, $attrs, bizflowContext) {
                return bizflowContext.appContextPath + '/js/angularjs/common/components/attachment/attachments.html';
            },
            bindings: {
                processId: '<',
                documentTypes: '<',
                showHideOriginals: '<?',
                isBulkProcess: '<?',
                readOnly: '<?',
                onChangeCallback: '&',
                processType: '<'
            },
            controller: CtrlAttachments
        });

    function CtrlAttachments(bizflowWih, bizflowContext, inform, $window, $uibModal, blockUI, $scope, $log, $timeout) {
        var vm = this;
        vm.customButtons = [];
        vm.enableRefreshButton = false;
        vm.attachments = [];
        vm.selectedTypeName = null;
        vm.currentActivityName = bizflowContext.custom.ACTIVITYNAME;
        vm.mainFormReadOnly = false;
        vm.isIncentivesDocuments = false;
        if (vm.readOnly === true) {
            vm.mainFormReadOnly = true;
        }

        if (typeof FormAttachmentHandler !== "undefined") {
            FormAttachmentHandler.setAngularControl(vm);
            vm.customButtons = FormAttachmentHandler.getCustomButtons();
            vm.enableRefreshButton = FormAttachmentHandler.enableRefreshButton;
            if (FormAttachmentHandler.isIncentivesDocuments) {
                vm.isIncentivesDocuments = FormAttachmentHandler.isIncentivesDocuments();
            }
        }

        vm.updateCustomButtons = function (customButtons) {
            vm.customButtons = customButtons;
        };

        vm.$onInit = function () {
            if (bizflowWih.basicWih) {
                bizflowWih.setChangeWorkitemAttachmentCallback(function () {
                    vm.reloadAttachments();
                });
            }
            vm.loadAttachments();

            if (typeof FormAttachmentHandler !== "undefined") {
                if (typeof FormAttachmentHandler.onInit === 'function') {
                    FormAttachmentHandler.onInit();
                }
            }

            try {
                $timeout(function () {
                    $scope.$apply(function () {
                        vm.currentActivityName = bizflowContext.custom.ACTIVITYNAME;
                        vm.mainFormReadOnly = false;
                        if (vm.readOnly === true) {
                            vm.mainFormReadOnly = true;
                        }
                    });
                });
            } catch (e) {
            }
        };

        vm.showAddButton = function () {
            return vm.mainFormReadOnly !== true && (vm.currentActivityName !== 'Confirm BUS Code' && vm.currentActivityName !== 'Approve PD Coversheet - SO');
        };

        vm.$onDestroy = function () {
        };

        /**
         * Attachments
         */
        vm.loadAttachments = function () {
            if (bizflowWih && bizflowWih.basicWih) { // Get attachments from basic WIH
                if (vm.documentTypes) {
                    vm.attachments = bizflowWih.getAttachments();
                    if (vm.attachments != null && vm.attachments.length) {
                        for (var i = 0; i < vm.attachments.length; i++) {
                            var category = vm.documentTypes.dataMap[vm.attachments[i].CATEGORY];
                            if (category && category.length > 0) {
                                vm.attachments[i].category = category;
                            } else {
                                vm.attachments[i].category = {'LABEL': vm.attachments[i].CATEGORY};
                            }
                            vm.attachments[i]._creationDate = new Date(vm.attachments[i].CREATIONDATE);
                        }
                        vm.onChangeCallback();
                    }
                }
            } else {
                console.log('ERROR - No BizFlow Workitem Handler found!')
            }
        };

        vm.reloadAttachments = function () {
            vm.loadAttachments();
            blockUI.stop();
            $scope.$digest();
        };

        function getAttachmentUrl(processId, attachmentId, filename, serverId) {
            var url = bizflowContext.getUrl("/instance/pigetattachfile.jsp") + "?PROCESSID=" + processId + "&IID=" + attachmentId + "&serverid=" + serverId
                + "&FILENAME=" + encodeURIComponent(filename) + "&PKIVALUE=N&ATTDESC=false";
            return url;
        }

        vm.getAttachmentUrl = function (processId, attachmentId, filename, serverId) {
            var url = bizflowWih.getAttachmentUrl(processId, attachmentId);
            if (typeof url === 'undefined') {
                url = getAttachmentUrl(processId, attachmentId, filename, serverId);
            }
            return url;
        };

        vm.clickAttachmentReviewed = function (attachment) {
            if (typeof FormAttachmentHandler !== "undefined" && typeof FormAttachmentHandler.clickAttachmentReviewed === 'function') {
                FormAttachmentHandler.clickAttachmentReviewed(attachment);
            }
        };

        vm.deleteAttachment = function (id) {
            bootbox.confirm('Do you want to delete the file?', function (result) {
                if (result) {
                    if (!bizflowWih.basicWih) {
                        alert('Deleting Document Type requires Workitem Handler');
                    } else {
                        var auditActor = $('#h_currentUserMemberID').val();
                        var auditActorName = $('#h_currentUserName').text();
                        var auditProcID = $('#h_procid').val();
                        var auditFileName = '';
                        var auditDocumentCategory = '';

                        for (var i = 0; i < vm.attachments.length; i++) {
                            if (vm.attachments[i].ID === id) {
                                auditFileName = vm.attachments[i].FILENAME;
                                auditDocumentCategory = vm.attachments[i].CATEGORY;
                            }
                        }

                        $.ajax({
                            type: 'POST',
                            url: '/bizflowwebmaker/cms_common/audit.do',
                            data: {
                                eventtype: 'delete',
                                procid: auditProcID,
                                userid: auditActor,
                                username: auditActorName,
                                filename: auditFileName,
                                category: auditDocumentCategory
                            },
                            dataType: 'xml',
                            cache: false,
                            success: function (response) {
                                //
                            }
                        });

                        bizflowWih.removeAttachment(id, function () {
                            bizflowWih.reloadAttachments();
                            vm.onChangeCallback();
                        });
                    }
                }
            });
        };

        vm.updateAttachmentDocType = function (attachment, newDocType, metadata) {
            if (!bizflowWih.basicWih) {
                inform.add('Updating Document Type requires Workitem Handler', {
                    ttl: 3000
                });
            } else {
                attachment.CATEGORY = newDocType;
                if (metadata !== undefined) {
                    attachment.edmsMetadata = metadata;
                }
                bizflowWih.updateAttachments(angularExt.objectToArray(attachment));
                vm.loadAttachments();
            }
        };

        vm.replaceAttachment = function (attachment) {
            $uibModal.open({
                template: '<replace-attachment ' +
                    '$close="$close(result)" ' +
                    'callback="$ctrl.callback" selected-attachment="$ctrl.selectedAttachment"></add-attachment>',
                backdrop: 'static',
                animation: true,
                size: 'lg',
                windowClass: 'attachmentAddWindow',
                controller: function () {
                    this.callback = vm.reloadAttachments;
                    this.selectedAttachment = attachment;
                },
                controllerAs: '$ctrl'
            }).result.then(function (result) {
                vm.onChangeCallback();
            });
        };

        vm.addAttachment = function (selectedTypeName) {
            $uibModal.open({
                template: '<add-attachment $close="$close(result)" document-types="$ctrl.documentTypes" callback="$ctrl.callback" selected-type-name="$ctrl.selectedTypeName"></add-attachment>',
                backdrop: 'static',
                animation: true,
                appendTo: (selectedTypeName ? '' : angular.element('#cmscommon_attachmentBody')),
                size: 'lg',
                windowClass: 'attachmentAddWindow',
                controller: function () {
                    this.documentTypes = vm.documentTypes;
                    this.callback = vm.reloadAttachments;
                    vm.selectedTypeName = selectedTypeName
                    this.selectedTypeName = vm.selectedTypeName;
                },
                controllerAs: '$ctrl'
            }).result.then(function (result) {
                vm.onChangeCallback();
            });
        };

        vm.viewAllViewableAttachments = function () {
            $window.getAppScope = function () {
                vm.bizflowWih = bizflowWih;
                return vm;
            };
            $window.open(bizflowContext.appContextPath + '/common/components/attachment/attachment-carousel-viewer-app.html?procid=' + vm.processId, 'ViewAttachments', 'toolbar=0,resizable=1');
        };

        vm.openModalViewAllViewableAttachments = function () {
            var modalInstance = $uibModal.open({
                templateUrl: '../fragments/attachment-carousel-viewer.html',
                controller: 'viewAttachmentsController',
                resolve: {
                    attachments: function () {
                        return vm.attachments;
                    },
                    callback: function () {
                        return function () {
                        }
                    }
                },
                windowClass: 'attachmentViewWindow',
                size: 'lg'
            });
        };

        vm.reloadAttachments2 = function () {
            bizflowWih.basicWih.reloadAttachments({event: 'UPDATED', forceLoad: true});
        };
        vm.getBizFlowWih = function () {
            return bizflowWih;
        };
        vm.callAttachmentService = function (url, params, msg, callback, reloadAttachment, failureCallback) {
            blockUI.start();

            $.ajax({
                type: 'POST',
                url: bizflowContext.getUrl(url),
                data: params,
                dataType: 'json',
                cache: false,
                success: function (response) {
                    $scope.$apply(function () {
                        blockUI.stop();
                    });
                    if (response.success) {
                        if (typeof reloadAttachment === 'undefined' || reloadAttachment) {
                            vm.reloadAttachments2();
                        }
                        if (typeof callback === 'function') {
                            callback(response);
                        }
                        if (msg) {
                            bootbox.alert(msg);
                        }
                        vm.onChangeCallback();
                    } else {
                        if (typeof failureCallback === 'function') {
                            failureCallback(response);
                        } else {
                            if (response.message) {
                                bootbox.alert(response.message);
                            }
                        }
                    }
                },
                error: function (error) {
                    $scope.$apply(function () {
                        blockUI.stop();
                    });
                    console.error(error.responseText);
                    if (typeof failureCallback === 'function') {
                        failureCallback(error);
                    }
                }
            });
        };
        vm.callGenerateDocument = function (url, params, msg, callback, failureCallback) {
            vm.callAttachmentService(url, params, msg, callback, true, failureCallback);
        };
        vm.getAssociatedAttachments = function (url, params, msg, callback, failureCallback) {
            vm.callAttachmentService(url, params, msg, callback, false, failureCallback);
        };
    }

    angular.module('bizflow.angular.component')
        .component('attachmentList', {
            templateUrl: function ($element, $attrs, bizflowContext) {
                return bizflowContext.appContextPath + '/js/angularjs/common/components/attachment/attachment-list.html';
            },
            bindings: {
                documentTypes: '<',
                showHideOriginals: '<?',
                showReviewed: '<?',
                readOnlyReviewed: '<?',
                isBulkProcess: '<?',
                readOnly: '<?',
                attachments: '=',
                processType: '<?'
            },
            require: {
                main: '^attachments'
            },
            controller: CtrlAttachmentList
        });

    function CtrlAttachmentList($log) {
        var vm = this;
        vm.$onInit = function () {
        };

        vm.$onDestroy = function () {
        };

        vm.showDeleteButton = function (attachment) {
            var showButton = false;
            if (vm.main.mainFormReadOnly != true && vm.main.deleteAttachment) {
                if (typeof FormAttachmentHandler !== "undefined") {
                    if (typeof FormAttachmentHandler.isAttachmentDeletable === 'function') {
                        showButton = FormAttachmentHandler.isAttachmentDeletable(attachment);
                    }
                }
            }
            return showButton;
        };

        vm.showReplaceButton = function (attachment) {
            var showButton = false;
            if (vm.main.mainFormReadOnly !== true && vm.main.replaceAttachment) {
                if (typeof FormAttachmentHandler !== "undefined") {
                    if (typeof FormAttachmentHandler.isAttachmentReplaceable === 'function') {
                        showButton = FormAttachmentHandler.isAttachmentReplaceable(attachment);
                    }
                }
            }
            return showButton;
        };
    }

    angular.module('bizflow.angular.component')
        .component('addAttachment', {
            templateUrl: function ($element, $attrs, bizflowContext) {
                return bizflowContext.appContextPath + '/js/angularjs/common/components/attachment/attachment-add.html';
            },
            bindings: {
                $close: '&',
                documentTypes: '=',
                callback: '=',
                selectedTypeName: '='
            },
            controller: CtrlAddAttachment
        });

    function CtrlAddAttachment($scope, $timeout, bizflowContext, FileUploader, bizflowWih, blockUI) {
        var vm = this;
        vm.selectedType = null;

        vm.$onInit = function () {
            if (vm.selectedTypeName != null) {
                for (var index = 0; index < vm.documentTypes.length; index++) {
                    if (vm.documentTypes[index].Name == vm.selectedTypeName) {
                        vm.selectedType = vm.documentTypes[index];
                        break;
                    }
                }
            } else {
                if (typeof FormAttachmentHandler !== "undefined") {
                    if (typeof FormAttachmentHandler.isDocumentTypeNotAddable === 'function') {
                        var count = vm.documentTypes.length;
                        for (var index = count - 1; index >= 0; index--) {
                            if (FormAttachmentHandler.isDocumentTypeNotAddable(vm.documentTypes[index])) {
                                vm.documentTypes.splice(index, 1);
                            }
                        }
                    }
                }
            }
        };

        var config;
        if (bizflowWih.basicWih) {
            config = {
                url: bizflowContext.getUrl('/bizcoves/wih/attachUpload.jsp?basicWihReadOnly=n'),
                formData: [{
                    attachType: 'file',
                    attachUrlName: '',
                    attachUrl: '',
                    hdmMetaFilePath: '',
                    responseType: 'JSON'
                }]
            };
        } else {
            config = {
                url: bizflowContext.getServiceUrl('/bizflow/attachment/upload.json'),
                formData: [{
                    processId: bizflowContext.custom.PROCESSID,
                    responseType: 'JSON'
                }]
            };
        }

        vm.uploader = $scope.uploader = new FileUploader(config);

        vm.uploader.onAfterAddingFile = function (fileItem) {
            var lastDotIndex = fileItem.file.name.lastIndexOf('\.');
            if (lastDotIndex > -1) {
                fileItem.namePart = fileItem.file.name.substring(0, lastDotIndex);
                fileItem.extPart = fileItem.file.name.substring(lastDotIndex);
            } else {
                fileItem.namePart = fileItem.file.name;
                fileItem.extPart = '';
            }
        };

        vm.isReadyToUpload = function () {
            if (vm.uploader.queue.length && vm.uploader.queue.length > 0) {
                for (var i = 0; i < vm.uploader.queue.length; i++) {
                    var item = vm.uploader.queue[i];
                    if (angularExt.isInvalidObject(item.category)) {
                        if (vm.selectedType != null) {
                            item.category = vm.selectedType
                        } else {
                            return false;
                        }
                    }
                    if (item.namePart.trim().length === 0) {
                        return false;
                    }
                    item.file.name = item.namePart + item.extPart;
                }
                return true;
            }
            return false;
        };

        vm.upload = function () {
            if (vm.uploader.queue.length === 0) {
                alert('Please Select File(s)');
            } else if (vm.uploader.queue.filter(function (el) {
                return el.category === undefined
            }).length > 0) {
                alert('Please Select Document Type');
            } else {
                $timeout(function () {
                    blockUI.start();
                }, 1);
                vm.uploader.uploadAll();
            }
        };

        vm.cancel = function () {
            vm.uploader.clearQueue();
            vm.$close({
                result: 'cancel'
            });
        };

        vm.uploader.filters.push({
            name: 'customFilter',
            fn: function (item, options) {
                return this.queue.length < 10;
            }
        });

        vm.uploader.onBeforeUploadItem = function (item) {
            if (item.category) {
                item.error = null;
                var formData = [{
                    category: item.category.Name,
                    description: item.description || '',
                    etcInfo: '',
                    edmsMetadata: ''
                }];
                Array.prototype.push.apply(item.formData, formData);
            }
        };

        vm.isUseSection508 = function () {
            if (typeof FormSection508 !== "undefined") return FormSection508.isUseSection508();
            else return false;
        };

        vm.uploader.onProgressAll = function (progress) {
            var bar = document.getElementById("upload_progressbar");
            if (bar) {
                bar.setAttribute("aria-valuenow", progress);
                bar.setAttribute("aria-valuetext", progress + " % uploaded");
                bar.innerText = progress + " %";
            }
        };

        vm.uploader.onCompleteAll = function () {
            vm.uploader.clearQueue();
            vm.$close({
                result: 'cancel'
            });
            if (bizflowWih && bizflowWih.basicWih) {
                bizflowWih.reloadAttachments();
            }
            if (vm.callback) {
                vm.callback();
            } else {
                blockUI.stop();
            }
            if (typeof FormSection508 !== "undefined") {
                if (FormSection508.isUseSection508()) {
                    // bootbox.alert("All files have been uploaded.");
                    alert("All documents have been successfully uploaded.");
                }
            }
        };

        vm.clickSelectFileButtonMouse = function () {
            setTimeout(function () {
                $('#hhsattachment_fileInput').trigger('click');
            })
        };
        vm.clickSelectFileButtonKeyboard = function (event) {
            if (event.type == 'keydown' && (event.key == ' ' || event.key == 'Enter')) {
                setTimeout(function () {
                    $('#hhsattachment_fileInput').trigger('click');
                })
            }
        }
    }

    angular.module('bizflow.angular.component')
        .component('replaceAttachment', {
            templateUrl: function ($element, $attrs, bizflowContext) {
                return bizflowContext.appContextPath + '/js/angularjs/common/components/attachment/attachment-replace.html';
            },
            bindings: {
                $close: '&',
                callback: '=',
                selectedAttachment: '='
            },
            controller: CtrlReplaceAttachment
        });

    function CtrlReplaceAttachment($scope, $timeout, bizflowContext, FileUploader, bizflowWih, blockUI) {
        var vm = this;

        var config = {};
        if (bizflowWih.basicWih) {
            config = {
                url: bizflowContext.getUrl('/bizcoves/wih/attachUpload.jsp?basicWihReadOnly=n'),
                formData: [{
                    attachType: 'file',
                    attachUrlName: '',
                    attachUrl: '',
                    hdmMetaFilePath: '',
                    responseType: 'JSON'
                }]
            };
        } else {
            config = {
                url: bizflowContext.getServiceUrl('/bizflow/attachment/upload.json'),
                formData: [{
                    processId: bizflowContext.custom.PROCESSID,
                    responseType: 'JSON'
                }]
            };
        }

        vm.uploader = $scope.uploader = new FileUploader(config);
        vm.uploader.clearQueue();

        vm.isTouchedBackground = false;
        vm.isReadyToUpload = function () {
            if (vm.uploader.queue.length && vm.uploader.queue.length > 0) {
                if (vm.isTouchedBackground == false) {
                    vm.isTouchedBackground = true;

                    $timeout(function () {
                        $('#cmscommon_attachment_button_section').focus();
                    }, 1);
                }
                return true;
            }
            return false;
        };

        vm.upload = function () {
            if (vm.uploader.queue.length == 0) {
                alert('Please Select File(s)');
            } else {
                $timeout(function () {
                    blockUI.start();
                }, 1);
                vm.uploader.uploadAll();
            }
        };

        vm.cancel = function () {
            vm.uploader.clearQueue();
            vm.$close({
                result: 'cancel'
            });
        };

        vm.uploader.filters.push({
            name: 'customFilter',
            fn: function (item, options) {
                return this.queue.length < 10;
            }
        });

        vm.uploader.onBeforeUploadItem = function (item) {
            item.error = null;
            var formData = [{
                action: 'update',
                attachSeq: vm.selectedAttachment.ID,
                description: vm.selectedAttachment.DESCRIPTION,
                category: vm.selectedAttachment.CATEGORY,
                etcInfo: vm.selectedAttachment.ETCINFO
            }];

            Array.prototype.push.apply(item.formData, formData);
        };

        vm.isUseSection508 = function () {
            if (typeof FormSection508 !== "undefined") return FormSection508.isUseSection508();
            else return false;
        };

        vm.uploader.onProgressAll = function (progress) {
            var bar = document.getElementById("upload_progressbar");
            if (bar) {
                bar.setAttribute("aria-valuenow", progress);
                bar.setAttribute("aria-valuetext", progress + " % uploaded");
                bar.innerText = progress + " %";
            }
        };

        vm.uploader.onCompleteAll = function () {
            vm.uploader.clearQueue();
            vm.$close({
                result: 'cancel'
            });
            if (bizflowWih && bizflowWih.basicWih) {
                bizflowWih.reloadAttachments();
            }
            if (vm.callback) {
                vm.callback();
            } else {
                blockUI.stop();
            }
            if (typeof FormSection508 !== "undefined") {
                if (FormSection508.isUseSection508()) {
                    // bootbox.alert("All files have been uploaded.");
                    alert("All documents have been successfully uploaded.");
                }
            }
        };

        vm.$onInit = function () {
            $('#cmscommon_attachment_button_section').focus();
        }
    }

    function buildViewAttachmentController($scope, attachments, bizflowWih) {
        $scope.attachments = attachments;
        $scope.getDocumentExt = function (attachment) {
            var ext = null;
            var filename = attachment.FILENAME;
            var idx = filename.lastIndexOf('.');
            if (idx !== -1) {
                ext = filename.substring(idx).toLowerCase();
            }

            return ext;
        };
        $scope.getAttachmentUrl = function (attachment) {
            return bizflowWih.getAttachmentUrl(attachment.ID);
        };
        $scope.isImage = function (attachment) {
            var v = false;
            var ext = this.getDocumentExt(attachment);
            if (ext !== null) {
                var visibleExts = '.png,.jpg,.jpeg,.gif,';
                v = visibleExts.indexOf(ext + ',') !== -1;
            }

            return v;
        };
        $scope.isNotVisibleDocumentInIE = function (ext) {
            var exts = '.pdf,';
            return exts.indexOf(ext + ',') === -1;
        };
        $scope.isVisibleDocument = function (attachment) {
            var v = false;
            var ext = this.getDocumentExt(attachment);
            if (ext !== null) {
                var visibleExts = '.pdf,.txt,';
                v = visibleExts.indexOf(ext + ',') !== -1;
            }

            return v;
        };
    }

    angular.module('bizflow.angular.component')
        .controller('viewAttachmentsController', ['$scope', '$uibModalInstance', 'attachments', 'bizflowWih',
            function ($scope, $uibModalInstance, attachments, bizflowWih) {
                buildViewAttachmentController($scope, attachments, bizflowWih);
                $scope.cancel = function () {
                    $uibModalInstance.dismiss('cancel');
                };
            }
        ]);

    angular.module('bizflow.angular.component')
        .component('generatePackage', {
            templateUrl: function ($element, $attrs, bizflowContext) {
                return bizflowContext.appContextPath + '/js/angularjs/common/components/attachment/generate-package.html';
            },
            bindings: {
                $close: '&',
                documentTypes: '=',
                callback: '=',
                attachments: '='
            },
            controller: CtrlGeneratePackage
        });

    function CtrlGeneratePackage($scope, $timeout, bizflowContext, bizflowWih, blockUI) {
        var vm = this;
        vm.selectedType = null;

        vm.selectedGrade;
        vm.grades = [];
        vm.exempts = [];
        vm.targetFileName = '';

        vm.attachmentFilter = function (attachment) {
            return attachment.FILEEXTENSION == 'pdf' && attachment.ETCINFO.indexOf('PACKAGE') == -1;
        };

        vm.getSelectedDocumentID = function () {
            var IDString = '';
            var selected = $('#PDFDocumentList input[name="PDFCheckBox"]:checked');

            var count = selected.length;
            for (var index = 0; index < count; index++) {
                IDString += selected[index].value;
                if (index + 1 < count) {
                    IDString += ',';
                }
            }
            return IDString;
        };

        vm.isReadyToRequest = function () {
            var isReady = false;
            var selectedIDString = vm.getSelectedDocumentID();
            if (vm.selectedGrade != 0 && vm.targetFileName.length > 0 && selectedIDString.length > 0) {
                isReady = true;
            }
            return isReady;
        };

        vm.cancel = function () {
            vm.$close({
                result: 'cancel'
            });
        };

        vm.getFinalFileName = function () {
            var index = vm.targetFileName.lastIndexOf('.pdf');
            if (index != -1 && index == vm.targetFileName.length - 4) {
                return vm.targetFileName;
            } else {
                return vm.targetFileName + '.pdf';
            }
        };

        vm.requestGeneratePackage = function () {
            vm.$close({
                result: {
                    result: 'ok',
                    grade: vm.selectedGrade,
                    filename: vm.getFinalFileName(),
                    files: vm.getSelectedDocumentID()
                }
            });
        };

        vm.$onInit = function () {
            for (var index = 1; index <= 5; index++) {
                var IDPredicate = '#CS_GR_ID_' + index + ' option:selected';
                var grade = $(IDPredicate).text();

                if (grade != null && grade.length > 0 && grade != 'Select One') {
                    vm.grades.push(grade);

                    var ExemptPredicate = '#CS_FLSA_DETERM_ID_' + index + ' option:selected';
                    var exempt = $(ExemptPredicate).text();
                    vm.exempts.push(exempt);
                } else {
                    break;
                }
            }

            if (vm.grades.length == 0) {
                vm.grades.push('N/A');
            }

            if (vm.selectedTypeName != null) {
                for (var index = 0; index < vm.documentTypes.length; index++) {
                    if (vm.documentTypes[index].Name == vm.selectedTypeName) {
                        vm.selectedType = vm.documentTypes[index];
                        break;
                    }
                }
            }

            vm.attachments.forEach(function (attachment) {
                attachment.selected = false;
            })
        }
    }

})();
