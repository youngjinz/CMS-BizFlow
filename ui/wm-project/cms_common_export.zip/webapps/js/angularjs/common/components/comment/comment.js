(function() {
    'use strict';
    
    angular.module('bizflow.angular.component')
        .component('comments', {
            templateUrl: function($element, $attrs, bizflowContext) {
                return '../cms_common/js/angularjs/common/components/comment/comments.html';
            },
            bindings: {
            },
            controller: CtrlComments
        });

    function CtrlComments(bizflowWih, bizflowContext, inform, $window, $uibModal, blockUI, $scope, $log, $timeout) {
        var vm = this;
        vm.comments = [];
        vm.currentActivityName = bizflowContext.custom.ACTIVITYNAME;
        vm.mainFormReadOnly = false;
        if (vm.readOnly == true){
            vm.mainFormReadOnly = true;
        }

        vm.$onInit = function() {
            if (bizflowWih.basicWih) {
                vm.comments = bizflowWih.basicWih.getComments();
            }

            try {
                $timeout(function() {
                    $scope.$apply(function() {
                        vm.currentActivityName = bizflowContext.custom.ACTIVITYNAME;
                        vm.mainFormReadOnly = false;
                        if (vm.readOnly == true){
                            vm.mainFormReadOnly = true;
                        }
                    });
                });
            } catch(e) {
            }
        };

        vm.$onDestroy = function() {
        };

        //--------------------------------
        // CMS Extension
        //--------------------------------
    }

    angular.module('bizflow.angular.component')
        .component('commentList', {
            templateUrl: function($element, $attrs, bizflowContext) {
                return '../cms_common/js/angularjs/common/components/comment/comment-list.html';
            },
            bindings: {
                readOnly: '<?',
                comments: '=',
            },
            require: {
                main: '^comments'
            },
            controller: CtrlCommentList
        });

    //function CtrlAddAttachment($scope, $timeout, bizflowContext, FileUploader, bizflowWih, blockUI) {
    function CtrlCommentList($log, bizflowContext, bizflowWih, blockUI) {
        var vm = this;
		
		vm.getAssociatedWorkflow = function(actName) {
			//return WorkflowInfoObject.getWorkflowName(actName) + " - " + actName;
            return actName;
		}

        vm.$onInit = function() {
        };

        vm.$onDestroy = function() {
        };
    }


})();
