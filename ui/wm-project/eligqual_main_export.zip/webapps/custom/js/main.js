var TabManager;

var EligQualMain = {

	_CMS_allUserGroups: null,

	_CMS_myUserGroups: null,

	actList: [{
		name: 'Conduct Eligibility and Qualifications Review',
		usergroup: [],
		tabs: ['tab1', 'tab2', 'tab3', 'tab6', 'tab7'],
		readonly: ['tab2']
	},{
		name: 'Update the Request',
		usergroup: [],
		tabs: ['tab1', 'tab2', 'tab3', 'tab6', 'tab7'],
		readonly: ['tab1', 'tab2', 'tab3']
	}, {
		name: 'Select Candidate for Appointment',
		usergroup: [],
		tabs: ['tab1', 'tab2', 'tab3', 'tab4', 'tab6', 'tab7'],
		readonly: ['tab1', 'tab2', 'tab3']
	}, {
		name: 'Approve Candidate for Appointment',
		usergroup: [],
		tabs: ['tab1', 'tab2', 'tab3', 'tab5', 'tab6', 'tab7'],
		readonly: ['tab1', 'tab2', 'tab3']
	}, {
		name: '_Archive_',
		usergroup: [],
		tabs: ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab6', 'tab7'],
		readonly: ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab6', 'tab7']
	}],

	tabList: [{
		id: 'tab1',
		targetUrl: '/eligqual/general.do',
		targetGroup: 'partial_tab1',
		name: 'General',
		loaded: false,
		completed: false,
		disabledHeader: false,
		onInit: function() {
            $('#SG_RT_ID').on("change", function() {
                EligQualMain.resetRequestType();
            });
            EligQualMain.resetRequestType();
            eligQualGen();
        },
		enableHandler: null
	}, {
		id: 'tab2',
		targetUrl: '/eligqual/position.do',
		targetGroup: 'partial_tab2',
		name: 'Position',
		loaded: false,
		completed: false,
		disabledHeader: false,
		onInit: function() {
            eligQualPos.init();
		},
		enableHandler: null
	}, {
		id: 'tab3',
		targetUrl: '/eligqual/review.do',
		targetGroup: 'partial_tab3',
		name: 'Review',
		loaded: false,
		completed: false,
		disabledHeader: false,
		onInit: function() {
            eligQualRev.init();
		},
		enableHandler: null
	}, {
		id: 'tab4',
		targetUrl: '/eligqual/select.do',
		targetGroup: 'partial_tab4',
		name: 'Selection',
		loaded: false,
		completed: false,
		disabledHeader: false,
		onInit: function() {
            eligQualSel.init();
		},
		enableHandler: null
	}, {
		id: 'tab5',
		targetUrl: '/eligqual/approve.do',
		targetGroup: 'partial_tab5',
		name: 'Approvals',
		loaded: false,
		completed: false,
		disabledHeader: false,
		onInit: function() {
            eligQualApr.init();
		},
		enableHandler: null
	}, {
		id: 'tab6',
		targetUrl: '/cmscommon/showAttachment.do',
		targetGroup: 'partial_tab6',
		name: 'Documents',
		loaded: false,
		completed: false,
        disabledHeader: false,
		displayMissingRequiredFields: false,
        onInit: function() {
            
        }
	}, {
        id: "tab7",
		targetUrl: "/cmscommon/showComment.do",
        targetGroup: "partial_tab7",
        name: "Notes",
        loaded: false,
        completed: false,
        disabledHeader: false,
		displayMissingRequiredFields: false,
        onInit: function() {            
        }
    }],

	activityOption: null,

	tabManager: null,

	removeSizeLabel: function(element) {
		var target = null;
		var nodeName = $(element).get(0).tagName;
		if (nodeName == 'input') {
			if ($(element).hasClass('dijitInputInner')) {
				target = $(element).parent().parent().parent();
			} else {
				target = $(element).parent().parent();
			}
		} else if (nodeName == 'textarea') {
			target = $(element).parent();
		}

		if (target != null && target.length > 0) {
			$(target).find('p.sizeLabel').remove();
		}
	},
	// The element with alwaysDisabled/alwaysReadonly attribute will be submitted to the webserver.
	// But, when the form is enabled, element will not be enabled.
	setAlwaysDisabled: function(elementID) {
		var element = $('#' + elementID);
		var selectorKey = '#' + elementID;
		$(element).attr('disabled','disabled');
		$(element).attr('alwaysDisabled','true');

		EligQualMain.removeSizeLabel(element);
	},
	setAlwaysReadonly: function(elementID) {
		var element = $('#' + elementID);
		$(element).prop('readonly','true');
		$(element).attr('alwaysReadonly','true');

		EligQualMain.removeSizeLabel(element);
	},
	isSpecialProgram: function() {
		var result = false;
		var requestType = $('#SG_RT_ID :selected').text();
		var appointmentType = $('#SG_AT_ID :selected').text();
		var specialPrograms = ['30% or more disabled veterans', 'Veteran Recruitment Appointment (VRA)', 'Volunteer', 'Schedule A']; // HRB-1427

		var foundProgram = CMSUtility.existInArray(specialPrograms, appointmentType);
		if (requestType == 'Appointment' && foundProgram == true) {
			CMSUtility.debugLog('ELIGQUALMAIN - EligQualMain.isSpecialProgram - This is Special Program.');
			result = true;
		} else {
			CMSUtility.debugLog('ELIGQUALMAIN - EligQualMain.isSpecialProgram - This is NOT Special Program.');
		}
		return result;
	},
	getUserGroupMemberID: function(userGroupName) {
		var userGroupMemberID = '';
		if (userGroupName == null || userGroupName.length == 0) {
			CMSUtility.debugLog('ELIGQUALMAIN - getUserGroupMemberID() - userGroupName is null or empty');
		}
		if (EligQualMain._CMS_allUserGroups == null) {
			var rawAllUserGroupData = $('#h_cms_usergroupString').val();
			if (rawAllUserGroupData != null && rawAllUserGroupData.length > 0) {
				$('#h_cms_usergroupString').val('');
				var x2js = new X2JS();
				EligQualMain._CMS_allUserGroups = x2js.xml_str2json(rawAllUserGroupData);
				x2js = null;
			} else {
				EligQualMain._CMS_allUserGroups = {UserGroups: {}};
			}
			CMSUtility.debugLog('ELIGQUALMAIN - getUserGroupMemberID() - Usergroup information is initialized.');
		}

		if (EligQualMain._CMS_allUserGroups != null
				&& EligQualMain._CMS_allUserGroups.cms_usergroup != null
				&& EligQualMain._CMS_allUserGroups.cms_usergroup.record != null) {
			var foundGroups = EligQualMain._CMS_allUserGroups.cms_usergroup.record.filter(function(node, index) {
				return node.NAME == userGroupName
			});
			if (foundGroups.length > 0) {
				userGroupMemberID = foundGroups[0].MEMBERID;
			}
		}
		return userGroupMemberID;
	},
	addButtonHandler: function(buttonID, validationRequired, buttonOptions, confirmMessage) {
		if (buttonID != null && buttonOptions != null) {
			var thisObj = this;  //CAUTION: this context change in callback
			$('#' + buttonID).off('click').on('click', function() {
                if (EligQualMain.checkFormBasicInfo('h_error_message') != true) {
                    return;
                }

				if (validationRequired == true) {
					var allTabCompleted = true;
					var activeTabs = thisObj.activityOption.getActiveTabList(thisObj.activityOption.getActivityName());
					for (var tabIndex = 0; tabIndex < activeTabs.length; tabIndex++) {
						var validated = thisObj.tabManager.validateTab(activeTabs[tabIndex]);
						if (validated == false) {
							return;
						}
					}

					var mandatoryDocumentsValid = $('#h_mandatoryDocumentsValid').val();
					if (mandatoryDocumentsValid != 'true') {
						thisObj.tabManager.enableTabHeader('tab6');
						thisObj.tabManager.enableTab('tab6');
						$('#' + CMSUtility.getAnchorID('tab6')).click();
						bootbox.alert('Please upload the missing required document(s).');
						return;
					}
				}

				if (confirmMessage != null && confirmMessage.length > 0) {
					bootbox.dialog({
							message: '<p class="bootbox-body">' + confirmMessage + '</p>',
							onEscape: true,
							buttons: [{
								label: 'Yes',
								className: 'btn-success',
								callback: function() {
									buttonOptions.forEach(function(option) {
										if (option.id == 'pv_requestStatusDate') {
											option.value = CMSUtility.getNowUTCString();
										}
										$('#' + option.id).val((typeof option.value == 'function' ? option.value() : option.value));
									})
									CMSUtility.greyOutScreen(true);
									thisObj.tabManager.enableTabsForSubmission();
									CMSUtility.submitFormPage(buttonID, 'saveNewForm');
								}
							}, {
								label: 'No',
								className: 'btn-danger'
							}]
						});
				} else {
					buttonOptions.forEach(function(option) {
						if (option.id == 'pv_requestStatusDate') {
							option.value = CMSUtility.getNowUTCString();
						}
						$('#' + option.id).val((typeof option.value == 'function' ? option.value() : option.value));
					})
					CMSUtility.greyOutScreen(true);
					thisObj.tabManager.enableTabsForSubmission();
					CMSUtility.submitFormPage(buttonID, 'saveNewForm');
				}
			});
		} else {
			CMSUtility.debugLog('ELIGQUALMAIN - addButtonHandler() - buttonID or buttonOption is null.');
		}
	}
	,
	initBasedOnActivity: function() {
		if (isReadOnly() == true) {
			$('#bottomSection').hide();
			return;
		}

		CMSUtility.debugLog('ELIGQUALMAIN - initBasedOnActivity - START');

		var activityName = this.activityOption.getActivityName();
		if (activityName == 'Conduct Eligibility and Qualifications Review') {
			EligQualMain.addButtonHandler('btnSubmitToComponent', true, [{
					id: 'WIH_complete_requested', value: 'true'
				}, {
					id: 'pv_eligQualCandidate', value: eligQualRev.getEligQualFlag
				}, {
					id: 'pv_returnToSO', value: 'No'
				}]);
			$('#btnReturnToSO').off('click').on('click', function() {
				$('#pv_returnToSO').val('Yes');
				EligQualMain.sendBackForModification('btnReturnToSO', [{
						id: 'pv_alertMessage', value: 'feedback'
					},{
						id: 'pv_feedbackStaffSpec', value: 'feedback'
					}]);
			});
			$('#action_button_conduct_review_group').removeClass('hide');
		} else if (activityName == 'Update the Request') {
			EligQualMain.addButtonHandler('btnSubmitToHr', true, [{
					id: 'WIH_complete_requested', value: 'true'
				}, {
					id: 'pv_selectOfficialReviewReq', value: 'Yes'
				}]);
			$('#action_button_update_request_group').removeClass('hide');
		} else if (activityName == 'Select Candidate for Appointment') {
			EligQualMain.addButtonHandler('btnSubmitToSelect', true, [{
					id: 'WIH_complete_requested', value: 'true'
				}, {
					id: 'pv_candidateApproved', value: eligQualSel.getSelectionFlag
				}, {
					id: 'pv_returnToHr', value: 'No'
				}]);
			$('#action_button_selection_group').removeClass('hide');
		} else if (activityName == 'Approve Candidate for Appointment') {
			EligQualMain.addButtonHandler('btnSubmitToApprove', true, [{
					id: 'WIH_complete_requested', value: 'true'
				}, {
					id: 'pv_candidateApproved', value: eligQualApr.getApprovalFlag
				}, {
					id: 'pv_returnToSO', value: 'No'
				}]);
			$('#btnReturnDcoToSO').off('click').on('click', function() {
				$('#pv_returnToSO').val('Yes');
				EligQualMain.sendBackForModification('btnReturnDcoToSO', [{
						id: 'pv_alertMessage', value: 'feedback'
					},{
						id: 'pv_feedbackDCO', value: 'feedback'
					}]);
			});
			$('#action_button_approve_group').removeClass('hide');
		} else {
			CMSUtility.debugLog('ELIGQUALMAIN - initBasedOnActivity() - No activity name matched [' + activityName + ']');
		}

		$('#btnCancelWorkitem').off('click').on('click', function() {
			EligQualMain.popupCancellation();
		});

		CMSUtility.debugLog('ELIGQUALMAIN - initBasedOnActivity - END');
	}
	,
	// Request Type in General Tab
	resetRequestType: function() {
		var requestTypeLabel = $('#SG_RT_ID option:selected').text();
		var requestTypeValue = $('#SG_RT_ID option:selected').val();

		if (requestTypeValue != '') {
			$('#requestType').text(requestTypeLabel);
		} else {
			$('#requestType').text('');
		}
		this.tabManager.resetTabs();
	},
	// This function will be called after getRequestNumber.do is completed.
	resetRequestNumber: function() {
		var requestNumber = $('#h_response_requestNumber').val();

		$('#h_requestNumber').val(requestNumber);
		$('#pv_requestStatus').val('Request Created');
		$('#requestNumber').text(requestNumber);
		$('#output_requestStatus').text('Request Created');
		var requestedStatusDate = $('#h_now').val();
		$('#pv_requestStatusDate').val(requestedStatusDate);
	},

	_currentUserGroupData: null,

	getCurrentUserGroupData: function() {
		if (EligQualMain._currentUserGroupData == null) {
			EligQualMain._currentUserGroupData = $('#h_userGroups').val();
			if (EligQualMain._currentUserGroupData == null || EligQualMain._currentUserGroupData.length == 0) {
				CMSUtility.debugLog('ELIGQUALMAIN - getCurrentUserGroupData() - ActivityName is null or empty.');
			} else {
				$('#h_userGroups').val('');
			}
		}
		return EligQualMain._currentUserGroupData;
	},
	_initUserGroupData: function() {
		var rawMyUserGroups = EligQualMain.getCurrentUserGroupData();
		if (rawMyUserGroups != null && rawMyUserGroups.length > 0) {
			var x2js = new X2JS();
			EligQualMain._CMS_myUserGroups = x2js.xml_str2json(rawMyUserGroups);
			x2js = null;
		} else {
			EligQualMain._CMS_myUserGroups = {UserGroups: {}};
		}
	},
	isCurrentUserMemberOf: function(userGroupName) {
		if (userGroupName == null || userGroupName.length == 0) {
			CMSUtility.debugLog('ELIGQUALMAIN - isCurrentUserMemberOf() - userGroupName is null or empty');
		}
		if (EligQualMain._CMS_myUserGroups == null) {
			EligQualMain._initUserGroupData();
		}

		if (EligQualMain._CMS_myUserGroups != null
				&& EligQualMain._CMS_myUserGroups.UserGroups != null
				&& EligQualMain._CMS_myUserGroups.UserGroups.UserGroup != null) {
			var foundGroups = EligQualMain._CMS_myUserGroups.UserGroups.UserGroup.filter(function(node, index) {
				return node.Name == userGroupName
			});
			return foundGroups.length > 0;
		} else {
			return false;
		}
	},
	// generates confirmation dialog for modification where additional message can be entered.
	// @param evtBtnId - element id of the button which triggered the dialog.
	// @param dataOptions - array of id/value pair.  If value is set as 'feedback', the value will be replaced with message from the dialog.
	sendBackForModification: function(evtBtnId, dataOptions) {
        if (EligQualMain.checkFormBasicInfo('h_error_message') != true) {
            return;
        }

		var thisObj = this;  //CAUTION: this context change
		var dialog = bootbox.dialog({
			title: 'Provide a summary of your changes',
			message: '<textarea rows="5" class="bootbox-input bootbox-input-text form-control"></textarea>',
			onEscape: true,
			buttons: {
				confirm: {
					label: 'OK',
					className: 'btn-success',
					callback: function() {
						var message = $('div.bootbox textarea').val();
						if (message != null && message.length > 0) {
							setTimeout(function() {
								$('#WIH_complete_requested').val('true');
								dataOptions.forEach(function(option){
									if (option.id == 'pv_requestStatusDate') {
										option.value = CMSUtility.getNowUTCString();
									}
									if (option.value == 'feedback'){
										// if option value is set as hardcoded 'feedback', replace it with text message from the dialog
										option.value = message;
									}
									$('#' + option.id).val((typeof option.value == 'function' ? option.value() : option.value));
								});
								CMSUtility.greyOutScreen(true);
								thisObj.tabManager.enableTabsForSubmission();
								CommentObject.addCommentToDB(message);
								CMSUtility.submitFormPage(evtBtnId, 'saveNewForm');
							}, 0);
						} else {
							return false;
						}
					}
				},
				cancel: {
					label: 'Cancel',
					className: 'btn-danger'
				}
			}
		});

		$('div.bootbox button.btn-success').prop('disabled', true);

		$('div.bootbox textarea').on('change keyup paste', function() {
			var message = $(this).val();
			if (message.length > 500) {
				$(this).val(message.substring(0, 500));
			}

			if (message.length == 0) {
				$('div.bootbox button.btn-success').prop('disabled', true);
			} else {
				$('div.bootbox button.btn-success').prop('disabled', false);
			}
		});
	},
	enableForModification: function() {
		var tabs = ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab6', 'tab7'];
		tabs.forEach(function(tab) {
			this.tabManager.enableTab(tab);
			EligQualMain.initMaxSizePerTab(tab);
		}, this)  //CAUTION: this context change

		var activityName = this.activityOption.getActivityName();
		var option = this.activityOption.getCurrentActivityOption(activityName);
		option.readonly = [];

		//TODO: adjust ELIGQUAL form specific elements
		hyf.util.enableComponent('button_apscm_return_2');
		CMSUtility.disableComponents(['IS_SO_ACK','IS_HR_CLS_SPC_APR','IS_HR_STF_SPC_APR','btnCancelWorkitem'])
	},
	popupModifyRequest: function() {
		bootbox.dialog({
			message: 'Are you sure you want to modify worksheet?',
			onEscape: true,
			buttons: [{
				label: 'Yes',
				className: 'btn-success',
				callback: EligQualMain.enableForModification
			}, {
				label: 'No',
				className: 'btn-danger'
			}]
		});
	},
	popupCancellation: function() {
        if (EligQualMain.checkFormBasicInfo('h_error_message') != true) {
            return;
        }
                
		var thisObj = this;  //CAUTION: this context change
		var isUserSO = EligQualMain.isCurrentUserMemberOf('Selecting Officials');
		var isUserLiaison = EligQualMain.isCurrentUserMemberOf('HR Liaison');
		var isXO = EligQualMain.isCurrentUserMemberOf('Executive Officers');
		var isClassificationSpecialist = EligQualMain.isCurrentUserMemberOf('HR Classification Specialists');
		var isStaffingSpecialist = EligQualMain.isCurrentUserMemberOf('HR Staffing Specialists');
		var isAdmin = EligQualMain.isCurrentUserMemberOf('Admin Team');

		var reasons = [];

		/* User Group Prioritization
		* 1. Admin {Admin, Budget, Component, HR}
		* 2. HR Classification Specialist {Budget, Component, HR}
		* 3. HR Staffing Specialist {Budget, Component, HR}
		* 4. HR Liaison {Budget, Component}
		* 5. XO {Budget, Component}
		* 6. SO {Budget, Component}
		* 7. Default {Budget, Component, HR}
		*/
		if (isAdmin == true) {
			reasons = LookupManager.findByLTYPE('UserGroup[Admin Team]/CancellationReason');
		} else if (isClassificationSpecialist == true) {
			reasons = LookupManager.findByLTYPE('UserGroup[HR Classification Specialists]/CancellationReason');
		} else if (isStaffingSpecialist == true) {
			reasons = LookupManager.findByLTYPE('UserGroup[HR Staffing Specialists]/CancellationReason');
		} else if (isUserLiaison == true) {
			reasons = LookupManager.findByLTYPE('UserGroup[HR Liaison]/CancellationReason');
		} else if (isXO == true) {
			reasons = LookupManager.findByLTYPE('UserGroup[Executive Officers]/CancellationReason');		
		} else if (isUserSO == true) {
			reasons = LookupManager.findByLTYPE('UserGroup[Selecting Officials]/CancellationReason');
		} else {
			reasons = LookupManager.findByLTYPE('UserGroup[Default]/CancellationReason');
		}

		var options = '<option value>Select one</option>';
		reasons.forEach(function(reason) {
			options = options + '<option value=' + reason.LABEL + '>' + reason.LABEL + '</option>';
		});

		var dialog = bootbox.dialog({
			title: 'Reason for Cancellation',
			message: '<span>Cancellation Reason</span><span class="mandatory" style="" title="Mandatory field"> * </span><span>:&nbsp;</span><select name="CancellationReason">' + options + '</select>',
			onEscape: true,
			buttons: {
				confirm: {
					label: 'OK',
					className: 'btn-success',
					callback: function() {
						var message = $('div.bootbox select option:selected').text();
						if (message == null || message.length == 0) {
							return false;
						}

						setTimeout(function() {
							CMSUtility.greyOutScreen(true);
							thisObj.tabManager.enableTabsForSubmission();
							$('#WIH_complete_requested').val('true');
							$('#pv_requestStatus').val('Request Cancelled');
							$('#pv_requestStatusDate').val(CMSUtility.getNowUTCString());
							$('#pv_CancelReason').val(message);
							CMSUtility.submitFormPage('btnCancelWorkitem', 'saveNewForm');
						}, 0);
					}
				},
				cancel: {
					label: 'Cancel',
					className: 'btn-danger'
				}
			}
		});

		$('div.bootbox button.btn-success').prop('disabled', true);

		$('div.bootbox select').on('change keyup', function() {
			var message = $('div.bootbox select option:selected').val();
			if (message == '') {
				$('div.bootbox button.btn-success').prop('disabled', true);
			} else {
				$('div.bootbox button.btn-success').prop('disabled', false);
			}
		});
	},
	showAlertMessage: function() {
		var msg = $('#pv_alertMessage').val();
		if (typeof msg != 'undefined' && msg != null && msg.length > 0){
			var dialog = bootbox.dialog({
				title: 'Requested Changes',
				message: '<textarea disabled rows="5" class="bootbox-input bootbox-input-text form-control">' + msg + '</textarea>',
				onEscape: true,
				buttons: {
					confirm: {
						label: 'OK',
						className: 'btn-success',
					}
				}
			});
			$('#pv_alertMessage').val(''); // once displayed alert message, erase so that it doesn't show up again before closing the form
		}
	},
	validateTabCustomCallback: function(tabId){
		var result = true;
		if (result == true && tabId == 'tab2'){
			result = validateEligQualPosCustom();
		}
		return result;
    },

    // This function will be called when SaveTabContentsForm is loaded.
    finishTabContent: function() {
        if (EligQualMain.checkFormBasicInfo('h_error_message_save') != true) {
            return;
        }
    },

    checkFormBasicInfo: function(errorElementID) {
        var result = false;
        try {
            var clientFormProcessID = $('#procid').val();
            var wihProcessID = basicWIHActionClient.getWorkitemContext().Process.ID
            var errorMessage = $('#' + errorElementID).val();
            if ((errorMessage != null && errorMessage.length > 0) || clientFormProcessID == null || wihProcessID == null || clientFormProcessID != wihProcessID) {
                bootbox.alert({
                    message: SYSTEM_ERROR_MESSAGE,
                    callback: function() {
                        basicWIHActionClient.exit({confirmMsg: null});
                    }
                });
            } else {
                result = true;
            }
        } catch (e) {
        }

        return result;
    },    

	//
	// eligqual_main ENTRY POINT
	//
	init: function() {
        CMSUtility.debugLog('ELIGQUALMAIN - init START');
        
        if (EligQualMain.checkFormBasicInfo('h_error_message') != true) {
            return;
        }
				
		// instantiate dependent objects
		this.activityOption = new BFActivityOption(this.actList, $('#h_activityName').val());
		this.tabManager = new TabManagerFactory(this.tabList, this.activityOption, 'tab6', 'tab7', 'EligQualMain', this.validateTabCustomCallback, this.showAlertMessage);
		TabManager = this.tabManager;
		
		// Following should be called to reduce redundant network traffic.
		EligQualMain.getCurrentUserGroupData();
		
		if (isReadOnly() == true) {
			var activityName = this.activityOption.getActivityName();
			var curActivityOption = this.activityOption.getCurrentActivityOption(activityName);
			curActivityOption.readonly = ['tab1', 'tab2', 'tab3', 'tab4', 'tab5'];
		}

		LookupManager.init();
		this.tabManager.installCustomTabChanger();
		this.tabManager.initTab(EligQualMain.tabList);

		// Request Date
		var requestedDateString = $('#h_creationdate').val();
		if (requestedDateString != null && requestedDateString.length > 0) {
			var requestedDate = new Date(requestedDateString);  // requestedDateString is GMT
			var newDate = new Date(requestedDate.getTime() - requestedDate.getTimezoneOffset() * 60000); // Adjust to local time
			var requestedDateLabel = CMSUtility.getDateString({isUTC: false, dateFormat: 'mm/dd/yyyy'}, newDate);
			$('#initiatedDate').text(requestedDateLabel);
		}

		// Request Number
		var requestNumber = $('#h_requestNumber').val();
		$('#requestNumber').text(requestNumber);

		// Request Status
		var requestStatus = $('#pv_requestStatus').val();
		$('#output_requestStatus').text(requestStatus);

		hyf.util.disableComponent('button_Previous');
		hyf.util.enableComponent('button_Next');

		EligQualMain.initBasedOnActivity();
		
		//----------------------------------------
		// static button event handler
		//----------------------------------------
		// save
		$('#btnSaveWorkitem').on('click', (function(){
            if (EligQualMain.checkFormBasicInfo('h_error_message') != true) {
                return;
            }

			$('#' + TabManagerFactory.CURRENT_TAB_ELEMID).val(this.activityOption.getCurrentTabID());
			this.tabManager.enableTabsForSubmission();
			CMSUtility.submitFormPage('btnSaveWorkitem', 'saveNewForm');
		}).bind(this));  //CAUTION: this context change

		// exit
		$('#btnExitWorkitem').on('click', (function(){
			this.tabManager.enableTabsForSubmission();
			CMSUtility.exitWitemHandler('btnExitWorkitem');
		}).bind(this));  //CAUTION: this context change


		// set focus on the current tab
		$('a.selectedTab').focus();

		CMSUtility.debugLog('ELIGQUALMAIN - init END');
	}
}

var _readOnly = null;
function isReadOnly() {
	if (_readOnly == null) {
		_readOnly = $('#h_readOnly').val();
		if (_readOnly == 'y') {
			_readOnly = true;
		} else {
			_readOnly = false;
		}
	}
	return _readOnly;
}


var SYSTEM_ERROR_MESSAGE = "<h3 style='color:red'>Something went wrong</h3><p><h4>The system has encountered an error. Please try again, and if it still doesn't work, contact EWITS 2.0 help desk.</h4>";

$(document).ready(function() {
    try {
        EligQualMain.init();
    } catch (e) {
        bootbox.alert({
            message: SYSTEM_ERROR_MESSAGE,
            callback: function() {
                basicWIHActionClient.exit({confirmMsg: null});
            }
        })
    }
});

$(document).ajaxError(function(event, request, settings, thrownError) {
    bootbox.alert(SYSTEM_ERROR_MESSAGE);
})