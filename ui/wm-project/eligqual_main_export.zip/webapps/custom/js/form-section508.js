'use strict';
if (!hyf.util.addMandatoryMarker) {
    hyf.util.addMandatoryMarker = function (field) {
        var mandatoryMarkerID = field + '_marker';
        var newMarkerSpan = document.createElement('span');
        newMarkerSpan.id = mandatoryMarkerID;
        newMarkerSpan.title = 'Mandatory field marker';
        newMarkerSpan.className = hyf.validation.config.mandatoryMarker.className;
        newMarkerSpan.style.cssText = hyf.validation.config.mandatoryMarker.style;
        newMarkerSpan.innerHTML = hyf.validation.config.mandatoryMarker.content;

        //work out where to put it
        switch (hyf.validation.config.mandatoryMarker.location) {
            case 'before_label':
                var labelForField = hyf.util.getFieldLabel(field);
                if (labelForField != null)
                    labelForField.insertBefore(newMarkerSpan, labelForField.firstChild);
                break;
            case 'after_label':
                var labelForField = hyf.util.getFieldLabel(field);
                if (labelForField != null)
                    labelForField.appendChild(newMarkerSpan);
                break;
            case 'before_control':
                var cb = hyf.util.getFieldControlBody(field)
                if (cb != null)
                    cb.insertBefore(newMarkerSpan, cb.firstChild);
                break;
            case 'after_control':
                var cb = hyf.util.getFieldControlBody(field)
                if (cb != null)
                    cb.appendChild(newMarkerSpan);
                break;
        }
    }
}

if (!hyf.util.removeMandatoryMarker) {
    hyf.util.removeMandatoryMarker = function (field) {
        var mandatoryMarkerID = field + '_marker';
        var mandatoryMarker = document.getElementById(mandatoryMarkerID);

        if (mandatoryMarker != null) {
            mandatoryMarker.parentNode.removeChild(mandatoryMarker);
        }
    }
}

if (!hyf.util.setErrorDisplayMethod) {
    hyf.util.setErrorDisplayMethod = function (method) {
        var ed = hyf.FMAction.getErrorDisplay();
        ed._displayMethod = method;
        return ed._displayMethod;
    }
}


(function (window) {
    var FormSection508 = function () {

        var _accessibilityOn = undefined;

        function getBizFlowModalPopupTop() {
            var _top = null;
            try {
                if (null != top && "undefined" != typeof(top)) {
                    if ("undefined" != typeof(top.getUserClientType) && "undefined" != typeof(top.openModalPopupWindow)) {
                        _top = top;
                    } else if (null != top.opener && "undefined" != typeof(top.opener)) {
                        if ("undefined" != typeof(top.opener.getUserClientType) && "undefined" != typeof(top.opener.openModalPopupWindow)) {
                            _top = top.opener;
                        } else if (null != top.opener.top && "undefined" != typeof(top.opener.top)) {
                            if ("undefined" != typeof(top.opener.top.getUserClientType) && "undefined" != typeof(top.opener.top.openModalPopupWindow)) {
                                _top = top.opener.top;
                            }
                        }
                    }
                } else if (parent) {
                    if (null != parent.top && "undefined" != typeof(parent.top)) {
                        if (typeof(parent.top.getUserClientType) != "undefined" && "undefined" != typeof(parent.top.openModalPopupWindow)) {
                            _top = parent.top;
                        } else if (null != parent.top.opener && "undefined" != typeof(parent.top.opener)) {
                            if ("undefined" != typeof(parent.top.opener.getUserClientType) && "undefined" != typeof(parent.top.opener.openModalPopupWindow)) {
                                _top = parent.top.opener;
                            } else if (null != parent.top.opener.top && "undefined" != typeof(parent.top.opener.top)) {
                                if ("undefined" != typeof(parent.top.opener.top.getUserClientType) && "undefined" != typeof(parent.top.opener.top.openModalPopupWindow)) {
                                    _top = parent.top.opener.top;
                                }
                            }
                        }
                    }
                }

                if (null == _top) {
                    if (top && "undefined" != typeof(top.WIH_information)) {
                        _top = top.WIH_information;
                    }
                }
            } catch (e) {
            }

            return _top;
        }

        function getUserAccessibilityPreference() {
            var top = getBizFlowModalPopupTop();
            if (top != null) {
                var workAreaFrame = top.document.getElementById("workAreaFrame");
                if (workAreaFrame != null) {
                    var doc = workAreaFrame.contentWindow.document || workAreaFrame.document;
                    if (doc != null) {
                        var imgs = doc.getElementsByTagName("img");
                        if (imgs != null) {
                            for (var i = 0; i < imgs.length; i++) {
                                var src = "" + imgs[i].src;
                                if (src.indexOf("icon_user_dis.gif") !== -1) {
                                    return true;
                                }
                            }
                        }
                    }
                }
            }

            return false;
        }

        function isAccessibilityOn() {
            if (undefined === _accessibilityOn) {
                _accessibilityOn = getUserAccessibilityPreference();
            }
            return _accessibilityOn;
        }

        function focusElement(elementId) {
            if (elementId) {
                var ele = document.getElementById(elementId);
                if (ele) {
                    ele.focus();
                }
            }
        }     

        var _useSection508 = isAccessibilityOn();
        var _errorDisplayMethod = null;
        var _tabPurities = [];

        function setAriaDescribedby(field) {
            var ariaDescribedby = field.getAttribute("aria-describedby");
            if (!ariaDescribedby) {
                ariaDescribedby = field.getAttribute("id") + "_error_message_container";
                field.setAttribute("aira-describedby", ariaDescribedby)
            }
        }

        function getMissingRequiredFieldsDescription(tabEle) {
			var firstReqFieldId = null;
            var html = "";
            var fv = hyf.FMAction.getFormValidator();
            var names = [];
            var cnt = 0;

            var fields = $(tabEle).find('input[_required="true"],select[_required="true"],textarea[_required="true"]' +
                ',input[aria-required="true"],select[aria-required="true"],textarea[aria-required="true"]' +
                ',input[_required_bak="true"],select[_required_bak="true"],textarea[_required_bak="true"]');

            $.each(fields, function (index, field) {
                field.setAttribute("_tabId", tabEle.id);
                var ele = $(field);
                if (ele.is(":visible") && !ele.attr('disabled') && !ele.attr('readonly')) {
                    var error;
                    if (field.getAttribute("aria-required")) {
                        var container = document.getElementById(field.id + "_container");
                        error = fv.checkWidgets(container, false, true);
                    } else {
                        error = fv.checkField(field, false, true);
                    }
                    if (error && error.length > 0) {
                        setAriaDescribedby(field);

                        var fieldLabel;
						var label508 = field.getAttribute("label508");
                        if (label508) {
                            fieldLabel = label508;
						} else {
							var label = $('#' + field.id + '_label').contents().get(0);
							if (!label && names.indexOf(field.name) === -1) {
								label = $('#' + field.name + '_label').contents().get(0);							
								names.push(field.name);
							}	
							if (label) {
                                fieldLabel = label.nodeValue;
							}
						}
                        if (fieldLabel) {
							if (null === firstReqFieldId) firstReqFieldId = field.id;
                            html += '<li tabindex="0" class="missing-required-field" fieldId="' + field.id + '" title="Enter or click to go to the ' + fieldLabel + ' field.">' + fieldLabel + '</li>';
                            cnt++;
                        }
                    }
                }
            });

            if (html.length === 0) {
                if (!$('#button_Next').is(":disabled")) {
                    html = "<li tabindex='0' class='missing-required-field' fieldId='_goToNext' title='Enter or click to go to Next'>Go to Next</li>";
                }
            }

            return {
				firstReqFieldId: firstReqFieldId,
                count: cnt,
                html: '<ol class="missing-required-fields">' + html + '</ol><hr>'
            };
        }

        function checkAutoCompletionPurity(id) {
            var acDisp = document.getElementById(id);
            if (acDisp) {
                var children = acDisp.getElementsByTagName("li");
                if (children && children.length > 0) {
                    return false;
                }
            }

            return true;
        }

        function checkTabPurity(tabId) {
            var fields = $("#" + tabId).find('input[type!="button"]:not(.hide):not(.disabled):not([readonly]):visible:enabled,textarea:not(.hide):not(.disabled):not([readonly]):visible:enabled');
            if (fields && fields.length > 0) {
                for (var i = 0; i < fields.length; i++) {
                    if ($(fields[i]).val() !== "") {
                        return false;
                    }
                }
            }

            fields = $("#" + tabId).find('input.ui-autocomplete-input:not(.hide):not(.disabled):not([readonly]):visible:enabled');
            if (fields && fields.length > 0) {
                for (var i = 0; i < fields.length; i++) {
                    var id = $(fields[i]).attr('id');
                    if (!checkAutoCompletionPurity(id + "_DISP")) return false; // CHECK THIS
                    else if (!checkAutoCompletionPurity(id + "_CUSTOMDISP")) return false; // CHECK THIS
                }
            }

            fields = $("#" + tabId).find('input[type="checkbox"]:not(.hide):not(.disabled):not([readonly]):visible:enabled:checked');
            if (fields && fields.length > 0) {
                return false;
            }


            fields = $("#" + tabId).find('input[type="radio"]:not(.hide):not(.disabled):not([readonly]):visible:enabled:checked');
            if (fields && fields.length > 0) {
                return false;
            }

            fields = $("#" + tabId).find('select:not(.hide):not(.disabled):not([readonly]):visible:enabled');
            if (fields && fields.length > 0) {
                for (var i = 0; i < fields.length; i++) {
                    if ($(fields[i]).val() !== "") {
                        return false;
                    }
                }
            }

            return true;
        }

        function getTabPurity(tabId) {
            var purity = _tabPurities[tabId];
            if (null != purity && purity === false) {
                return purity;
            }

            purity = checkTabPurity(tabId);
            _tabPurities[tabId] = purity;
            return purity;
        }

        function getMissingRequiredFieldTitle(tabId, desc) {
            var title;
            var purity = getTabPurity(tabId);
            if (purity) {
                if (desc.count === 1) {
                    title = "There is one required field";
                } else if (desc.count > 1) {
                    title = "There are " + desc.count + " required fields";
                } else {
                    title = "There is no required field";
                }
            } else {
                if (desc.count === 1) {
                    title = "One Missing Required Field";
                } else if (desc.count > 1) {
                    title = desc.count + " Missing Required Fields";
                } else {
                    title = "No Missing Required Field";
                }
            }

            return title;
        }
     
        function makeTabMissingRequiredFieldsDescription(tabId) {
            var tab = TabManager.getTab(tabId);
            if (tab.displayMissingRequiredFields) {
                var tabEle = document.getElementById(tabId);
                var divId = tabId + '_missing_required_fields';
                var divEle = document.getElementById(divId);
                if (divEle === null) {
                    divEle = document.createElement("div");
                    divEle.id = divId;
                    divEle.className = "missing-required";
                    tabEle.insertBefore(divEle, tabEle.firstChild);
                }
                var desc = getMissingRequiredFieldsDescription(tabEle, tabId);
                var title = getMissingRequiredFieldTitle(tabId, desc);

                var html = '<div class="panel-heading">';
                html += '<span tabindex="0" accesskey="m" class="panel-title" id="missingRequiredTitle">' + title + '</span>';
                if (desc.count > 0) {
                    html += ' (<span tabindex="0" class="panel-title-desc">Please press enter each list item to bring focus into the field</span>)';
                }
                html += '</div>';
                html += desc.html;
                divEle.innerHTML = html;
                $(divEle).find('li').on('click keyup', function (e) {
                    e = e || window.event;
                    if (e.type === 'click' || (e.type === 'keyup' && (e.key === ' ' || e.key === 'Enter'))) {
                        var target = e.target;
                        var fieldId = target.getAttribute("fieldId");
                        if (fieldId) {
                            if (fieldId === '_goToNext') {
                                $('#button_Next').click();
                            } else {
                                document.getElementById(fieldId).focus();
                            }
                        }
                    }
                });

                return desc.firstReqFieldId;
            }
        }

        function makeAllTabsMissingRequiredFieldsDescription() {
            var partialPageContainers = $('div.partialPageContainer[_use="tabPane"]');
            $.each(partialPageContainers, function (index, partialPageContainer) {
                makeTabMissingRequiredFieldsDescription(partialPageContainer.id);
            })
        }

        function removeMandatoryConstraint(e) {
            var target = e.target;
            var required = target.getAttribute("_required");
            if (required === 'true') {
                target.setAttribute("_required_bak", "true");
                hyf.util.setMandatoryConstraint(target.id, false);
                hyf.util.addMandatoryMarker(target.id);
            }
        }

        function setMandatoryConstraint(e) {
            var target = e.target;
            var required = target.getAttribute("_required_bak");
            if (required === 'true') {
                hyf.util.removeMandatoryMarker(target.id);
                hyf.util.setMandatoryConstraint(target.id, true);
                target.removeAttribute("_required_bak");
            }
        }

        function onElementFocus(e) {
            if (_errorDisplayMethod !== "text") {
                removeMandatoryConstraint(e);
            }
        }

        function onElementBlur(e) {
            var target = e.target;
            var tabId = target.getAttribute("_tabId");
            if (null === tabId) {
                tabId = TabManager.getSelectedTabID();
                target.setAttribute("_tabId", tabId);
            }

            if (_errorDisplayMethod !== "text") {
                setMandatoryConstraint(e);
            }
            makeTabMissingRequiredFieldsDescription(tabId);
        }

        function bindElements() {
            $('input[_required="true"]').on('focus', onElementFocus);
            $('input').on('blur', onElementBlur);
            $('input').on('autocomplete_select', onElementBlur);

            $('select[_required="true"]').on('focus', onElementFocus);
            $('select').on('blur', onElementBlur);

            $('textarea[_required="true"]').on('focus', onElementFocus);
            $('textarea').on('blur', onElementBlur);
        }

        function onTabChange() {
            var tabId = TabManager.getSelectedTabID();
            var firstReqFieldId = makeTabMissingRequiredFieldsDescription(tabId);
            focusElement(firstReqFieldId);
        }

        function init() {
            if (_useSection508) {
                _errorDisplayMethod = hyf.util.setErrorDisplayMethod("text");
                $(document).on('CMS_ALL_TAB_LOADED', function () {
                    $(document).on('ON_TAB_CHANGE', onTabChange);
                });
                bindElements();
                makeAllTabsMissingRequiredFieldsDescription();
            }
        }

        function setUseSection508(use) {
            _useSection508 = use;
        }

        function isUseSection508() {
            return _useSection508;
        }

        return {
            setUseSection508: setUseSection508,
            isUseSection508: isUseSection508,
            init: init
        }
    };

    var _initializer = window.FormSection508 || (window.FormSection508 = FormSection508());
})(window);
