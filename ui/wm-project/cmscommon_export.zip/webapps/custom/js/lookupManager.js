/*
    Lookup Manager object
    This object will manage lookup values in client side.

    Example of LookupItem Object
    {
        ACTIVE: "1",
        DISPORDER: "",
        ID: "500",
        LABEL: "Existing Position Description (PD)",
        LTYPE: "MDDocumentType",
        PARENTID: "477",
        children: null
    }
*/
var LookupManager = {
    jsonObject: null,
    /*
        Initialize lookup manager object. This function should be called before using LookupManager.
        This function will retrieve XML String from h_lookupXMLString element and coverts to JSON object.
    */
    init: function() {
        if (this.jsonObject == null) {
            var x2js = new X2JS();
            var lookupXML = $('#h_lookupXMLString').val();
            if (lookupXML == null || lookupXML.length == 0) {
                console.log("LookupManager - init() - no lookup items found from the form.");
            } else {
                $('#h_lookupXMLString').val('');
            }
            this.jsonObject = x2js.xml_str2json(lookupXML);
            this.generateHierarchy();
        } else {
            console.log("LookupManager - init() - Already initialized.");
        }
    },
    /*
        Initialize lookup manager object for testing.
        @param {string} jsonString - JSON string of lookup values.
    */
    init2: function(jsonString) { // For testing
        this.jsonObject = JSON.parse(jsonString);
        this.generateHierarchy();
    },
    /*
        Internal function searching Lookup values with ID
        @param {Array} items
        @param ID
        @return {lookupItem}
    */
    _findByID: function(items, ID) {
        if (items != null) {
            for (var index = 0; index < items.length; index++) {
                if (items[index].ID == ID) {
                    return items[index];
                }

                if (items[index].children != null && items[index].children.length > 0) {
                    var foundItem = this._findByID(items[index].children, ID);
                    if (foundItem != null) {
                        return foundItem;
                    }
                }
            }
            return null;
        }
    },
    /*
        Internal function generating lookup hierarchy.
    */
    generateHierarchy: function() {
        try {
            var items = this.jsonObject.lookup.record;
            if (items != null) {
                for (var index = 0; index < items.length; index++) {
                    if (items[index].PARENTID != '0') {
                        var parentItem = this._findByID(items, items[index].PARENTID);
                        if (parentItem != null) {
                            if (parentItem.children == null) {
                                parentItem.children = [];
                            }
                            parentItem.children.push(JSON.parse(JSON.stringify(items[index])));
                            items[index].movedToParent = true;
                        } else {
                            console.log("LookupManager - generateHierarchy() - Not found parent item[" + items[index].PARENTID + "] of child item[" + items[index].ID + "]");
                        }
                    }
                }

                for (var index = items.length - 1; index >= 0; index--) {
                    if (items[index].movedToParent == true) {
                        items.splice(index, 1);
                    }
                }
            }
        } catch (e) {
            console.log("LookupManager - generateHierarchy() - Failed to generate hierarchy.");
        }
    },
    /*
        Find lookup value with ID
        @param {string} ID
        @return {lookupItem}
    */
    findByID: function(ID) {
        if (this.jsonObject == null) {
            console.log("LookupManager - findByID() - LookupManager is not initialized. Call LookupManager.init() first.");
            return null;
        }
        return _findByID(jsonObject.lookup.record, ID);
    },
    /*
        Internal function searching lookup values with LType
        @param {Array} items
        @param {Array} pathArray
        @return {Array}
    */
    _findByLType: function(items, pathArray) {
        if (items == null || items.length == null || pathArray == null || pathArray.length == 0) {
            return null;
        }

        var targetPath = null;
        var targetLabel = null;
        var startIndex = pathArray[0].indexOf('[');
        if (startIndex == -1) {
            targetPath = pathArray[0];
            targetLabel = null;
        } else {
            targetPath = pathArray[0].substring(0, startIndex);
            targetLabel = pathArray[0].substring(startIndex + 1, pathArray[0].length - 1);
        }

        var foundItems = [];
        for (var index = 0; index < items.length; index++) {
            if (items[index].LTYPE == targetPath) {
                if (targetLabel != null) {
                    if (items[index].LABEL != targetLabel) {
                        continue;
                    }
                }
                if (pathArray.length == 1) {
                    foundItems.push(items[index]);
                } else {
                    var pathArrayClone = pathArray.slice();
                    pathArrayClone.splice(0, 1);
                    var foundItemsFromSub = this._findByLType(items[index].children, pathArrayClone);
                    if (foundItemsFromSub != null && foundItemsFromSub.length > 0) {
                        foundItems.push.apply(foundItems, foundItemsFromSub);
                    }
                }
            }
        }

        return foundItems;
    },

    /*
        Find lookup values with the path of LType
        @param {string} LTYPEPath - Path of LType. Ex) 'RequestType[Appointment]/ClassificationType' or 'RequestType'
        @return {Array}
    */
    // If LTYPEPath contains '/' as a value, not LTYPE Seperator, then '/' should be decorated as '*/*'
    // '*/*' will be translated to '/' after separating paths.

    findByLTYPE: function(LTYPEPath) {
        if (this.jsonObject == null) {
            console.log("LookupManager - findByLTYPE() - LookupManager is not initialized. Call LookupManager.init() first.");
            return null;
        }
        // var translatedLTYPEPath = LTYPEPath.replace(new RegExp('*/*'), '*_*');
        // var paths = translatedLTYPEPath.split('/');
        // var translatedPaths = [];
        // for (var index = 0; index < paths.length; index++) {
        //     var newPath = paths[index].LTYPEPath.replace(new RegExp('*_*'), '/');
        //     translatedPaths.push(newPath);
        // }
        var translatedLTYPEPath = LTYPEPath.split('*/*').join('*_*');
        var paths = translatedLTYPEPath.split('/');
        var translatedPaths = [];
        for (var index = 0; index < paths.length; index++) {
            var newPath = paths[index].split('*_*').join('/');
            translatedPaths.push(newPath);
        }

        var result = this._findByLType(this.jsonObject.lookup.record, translatedPaths);
        return result;
    }

}

// function TestLookupManager() {
//     var testResult = LookupManager.findByLTYPE('RequestType');
//     console.log(testResult);
//
//     var testResult = LookupManager.findByLTYPE('RequestType/ClassificationType');
//     console.log(testResult);
//
//     testResult = LookupManager.findByLTYPE('RequestType[Appointment]/ClassificationType');
//     console.log(testResult);
//
//     testResult = LookupManager.findByLTYPE('RequestType[Appointment]/ClassificationType[Update Major Duties]/MandatoryDocument');
//     console.log(testResult);
// }
